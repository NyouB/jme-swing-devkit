/*
 * Copyright (c) 2003-2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

/**
 * @author Karl Tauber
 */
class LayoutCreatorRegistry
	extends AbstractLookup<LayoutCreator, Object>
{
	private static LayoutCreatorRegistry instance;

	static synchronized LayoutCreatorRegistry getInstance() {
		if( instance == null )
			instance = new LayoutCreatorRegistry();
		return instance;
	}

	private LayoutCreatorRegistry() {
		super( true );

		String groupLayoutCreatorClass;
		try {
			// use Java 6 GroupLayout if available
			Class.forName( "javax.swing.GroupLayout" );
			groupLayoutCreatorClass = "com.jformdesigner.runtime.GroupLayout6Creator";

			Class.forName( groupLayoutCreatorClass ); // check whether is is available
		} catch( ClassNotFoundException ex ) {
			groupLayoutCreatorClass = "com.jformdesigner.runtime.GroupLayoutCreator";
		}

		put( "java.awt.BorderLayout",  "com.jformdesigner.runtime.BorderLayoutCreator" );
		put( "java.awt.CardLayout",    "com.jformdesigner.runtime.CardLayoutCreator" );
		put( "java.awt.FlowLayout",    "com.jformdesigner.runtime.FlowLayoutCreator" );
		put( "java.awt.GridLayout",    "com.jformdesigner.runtime.GridLayoutCreator" );
		put( "java.awt.GridBagLayout", "com.jformdesigner.runtime.GridBagLayoutCreator" );
		put( "javax.swing.BoxLayout",  "com.jformdesigner.runtime.BoxLayoutCreator" );
		put( "com.jformdesigner.runtime.NullLayout", "com.jformdesigner.runtime.NullLayoutCreator" );
		put( "org.jdesktop.layout.GroupLayout",      groupLayoutCreatorClass );
		put( "com.jgoodies.forms.layout.FormLayout", "com.jformdesigner.runtime.FormLayoutCreator" );
		put( "info.clearthought.layout.TableLayout", "com.jformdesigner.runtime.TableLayoutCreator" );
		put( "com.intellij.uiDesigner.core.GridLayoutManager", "com.jformdesigner.runtime.IntelliJGridLayoutCreator" );
		put( "net.miginfocom.swing.MigLayout", "com.jformdesigner.runtime.MigLayoutCreator" );
		put( "org.jdesktop.swingx.HorizontalLayout", "com.jformdesigner.runtime.HorizontalLayoutCreator" );
		put( "org.jdesktop.swingx.VerticalLayout", "com.jformdesigner.runtime.VerticalLayoutCreator" );

		put( "javax.swing.JLayeredPane", "com.jformdesigner.runtime.JLayeredPaneCreator" );
		put( "javax.swing.JMenu",        "com.jformdesigner.runtime.JMenuCreator" );
		put( "javax.swing.JMenuBar",     "com.jformdesigner.runtime.JMenuBarCreator" );
		put( "javax.swing.JPopupMenu",   "com.jformdesigner.runtime.JPopupMenuCreator" );
		put( "javax.swing.JScrollPane",  "com.jformdesigner.runtime.JScrollPaneCreator" );
		put( "javax.swing.JSplitPane",   "com.jformdesigner.runtime.JSplitPaneCreator" );
		put( "javax.swing.JTabbedPane",  "com.jformdesigner.runtime.JTabbedPaneCreator" );
		put( "javax.swing.JToolBar",     "com.jformdesigner.runtime.JToolBarCreator" );
		put( "javax.swing.JViewport",    "com.jformdesigner.runtime.JViewportCreator" );

		put( "com.jformdesigner.runtime.GenericIndexLayout",  "com.jformdesigner.runtime.GenericIndexLayoutCreator" );

		// deprecated (for compatibility)
		put( "javax.swing.ScrollPaneLayout", "com.jformdesigner.runtime.JScrollPaneCreator" );
		put( "javax.swing.plaf.basic.BasicTabbedPaneUI$TabbedPaneLayout",
				"com.jformdesigner.runtime.JTabbedPaneCreator" );
	}
}
