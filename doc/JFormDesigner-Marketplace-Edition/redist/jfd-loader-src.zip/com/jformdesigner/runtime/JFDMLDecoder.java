/*
 * Copyright (c) 2011 Karl Tauber <karl at jformdesigner dot com>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  o Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *  o Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.jformdesigner.runtime;

import java.beans.ExceptionListener;
import java.beans.Expression;
import java.io.*;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author Karl Tauber
 * @since 5.1
 */
public class JFDMLDecoder
	implements AutoCloseable
{
	private static final Object VOID = new Object();
	private static final Map<String, Class<?>> primitiveTypeMap = new HashMap<>();

	private final InputStream in;
	private Object owner;
	private ExceptionListener exceptionListener;
	private final ClassLoader classLoader;
	private JFDMLClassNameMapper classNameMapper;
	private Map<String, String> headerAttributes;

	private Lexer lexer;
	private Map<String, Object> idToValueMap;

	private Object[] objects;
	private int objectIndex;

	public JFDMLDecoder( InputStream in ) {
		this( in, null, null, null );
	}

	public JFDMLDecoder( InputStream in, Object owner, ExceptionListener exceptionListener, ClassLoader classLoader ) {
		this.in = in;
		this.owner = owner;
		this.exceptionListener = exceptionListener;
		this.classLoader = classLoader;
	}

	public Object getOwner() {
		return owner;
	}

	public void setOwner( Object owner ) {
		this.owner = owner;
	}

	public ExceptionListener getExceptionListener() {
		return exceptionListener;
	}

	public void setExceptionListener( ExceptionListener exceptionListener ) {
		this.exceptionListener = exceptionListener;
	}

	private void exceptionThrown( Exception ex ) {
		if( exceptionListener != null )
			exceptionListener.exceptionThrown( ex );
		else {
			System.err.println( ex );
			System.err.println( "Continuing..." );
		}
	}

	public JFDMLClassNameMapper getClassNameMapper() {
		return classNameMapper;
	}

	public void setClassNameMapper( JFDMLClassNameMapper classNameMapper ) {
		this.classNameMapper = classNameMapper;
	}

	public Map<String, String> getHeaderAttributes() {
		if( headerAttributes != null )
			return headerAttributes;
		else
			return Collections.emptyMap();
	}

	@Override
	public void close() {
		parseAll();

		try {
			in.close();
			if( lexer != null )
				lexer.close();
		} catch( IOException ex ) {
			exceptionThrown( ex );
		}
	}

	private void initLexer() throws SyntaxException, IOException {
		if( lexer != null )
			return;

		String encoding = null;
		int firstLineLength = 0;
		byte[] firstLineBuf = new byte[100];
		InputStream lin = in;

		// read first line
		int ch;
		while( (ch = in.read()) != '\n' && ch != '\r' && ch >= 0 ) {
			if( firstLineLength >= firstLineBuf.length ) {
				byte[] newBuffer = new byte[firstLineBuf.length + 100];
				System.arraycopy( firstLineBuf, 0, newBuffer, 0, firstLineBuf.length );
				firstLineBuf = newBuffer;
			}
			firstLineBuf[firstLineLength++] = (byte) ch;
		}

		// parse first line
		if( firstLineLength > 0 ) {
			Lexer headerLexer = new Lexer( new InputStreamReader(
				new ByteArrayInputStream( firstLineBuf, 0, firstLineLength ), "UTF-8" ) );
			if( headerLexer.nextToken() == Lexer.IDENTIFIER && "JFDML".equals( headerLexer.value ) ) {
				// parse header
				//   Syntax: JFDML (name: "value")*
				headerAttributes = new LinkedHashMap<>();

				while( headerLexer.peekToken() != Lexer.EOF ) {
					if( headerLexer.nextToken() != Lexer.IDENTIFIER )
						continue;

					String name = (String) headerLexer.value;
					if( headerLexer.nextToken() != ':' ||
						headerLexer.nextToken() != Lexer.STRING )
					  continue;

					String value = (String) headerLexer.value;
					headerAttributes.put( name, value );
				}

				encoding = headerAttributes.get( "encoding" );
			} else {
				// input stream does not start with a header --> push back first line
				PushbackInputStream pbin = new PushbackInputStream( in, firstLineLength + 1 );
				if( ch >= 0 )
					pbin.unread( ch );
				pbin.unread( firstLineBuf, 0, firstLineLength );
				lin = pbin;
			}
		}

		// create lexer for parsing JFDML
		lexer = new Lexer( new InputStreamReader( lin, (encoding != null) ? encoding : "UTF-8" ) );
	}

	public Object readObject()
		throws ArrayIndexOutOfBoundsException
	{
		parseAll();
		return (objects != null) ? objects[objectIndex++] : null;
	}

	private void parseAll() {
		if( objects != null )
			return;

		ArrayList<Object> list = new ArrayList<>();

		try {
			initLexer();
			while( lexer.peekToken() != Lexer.EOF ) {
				Object value = parseValue( this );
				if( value != VOID )
					list.add( value );
			}
		} catch( Exception ex ) {
			exceptionThrown( ex );
		}

		objects = list.toArray();
	}

	/**
	 * object
	 *     : VOID? id? expression (LEFT_BRACE object+ RIGHT_BRACE)?
	 *     ;
	 */
	private Object parseObject( Object outer ) throws SyntaxException, IOException {
		boolean isVoid = false;
		if( lexer.peekToken() == Lexer.IDENTIFIER && lexer.value.equals( "void" ) ) {
			lexer.nextToken(); // skip void
			isVoid = true;
		}

		String id = null;
		if( lexer.peekToken() == '&' ) {
			lexer.nextToken(); // skip '&'
			id = parseIdentifier();
		}

		boolean[] voidExpression = new boolean[1];
		Object object = parseExpression( outer, voidExpression );

		if( id != null ) {
			if( idToValueMap == null )
				idToValueMap = new HashMap<>();
			idToValueMap.put( id, object );
		}

		int token = lexer.peekToken();
		if( token == '{' ) {
			lexer.nextToken(); // skip '{'
			do {
				parseObject( object );
				token = lexer.peekToken();
			} while( token != Lexer.EOF && token != '}' );
			lexer.nextToken(); // skip '}'
		}

		if( isVoid || voidExpression[0] || object == VOID )
			return VOID;

		return object;
	}

	/**
	 * expression
	 *     : NEW ClassName (argumentList|array)?
	 *     | MethodName argumentList
	 *     | STATIC ClassName MethodName argumentList
	 *     | FIELD FieldName (COLON value)?
	 *     | STATIC_FIELD ClassName FieldName (COLON value)?
	 *     | ENUM ClassName FieldName
	 *     | CLASS ClassName
	 *     | PropertyName COLON value?
	 *     | String COLON value
	 *     | THIS
	 *     | idref
	 *     ;
	 */
	private Object parseExpression( Object outer, boolean[] voidExpression ) throws SyntaxException, IOException {
		int token = lexer.nextToken();
		if( token == Lexer.IDENTIFIER ) {
			String methodName = (String) lexer.value;

			int nextToken = lexer.peekToken();
			if( nextToken == '(' ) {
				// Syntax: MethodName argumentList
				Object[] args = parseArgumentList();

				return getExpressionValue( outer, methodName, args );

			} else if( nextToken == ':' ) {
				// Syntax: PropertyName COLON value?
				lexer.nextToken(); // skip ':'
				if( lexer.peekToken() == '{' ) {
					// get property value
					if( voidExpression != null )
						voidExpression[0] = true;

					methodName = capitalize( "get", methodName );
					return getExpressionValue( outer, methodName, null );

				} else {
					// set property value
					Object value = parseNonVoidValue( null );

					methodName = capitalize( "set", methodName );
					getExpressionValue( outer, methodName, new Object[] { value } );
					return VOID;
				}

			} else if( methodName.equals( "new" ) ) {
				// Syntax: NEW ClassName (argumentList|array)?
				String className = parseFQClassName();
				Class<?> cls = findClass( className );

				int nextToken2 = lexer.peekToken();
				if( nextToken2 == '[' )
					return parseArray( cls );
				else {
					Object[] args = (nextToken2 == '(') ? parseArgumentList() : null;
					if( cls == null )
						return null;
					return getExpressionValue( cls, "new", args );
				}

			} else if( methodName.equals( "static" ) ) {
				// Syntax: STATIC ClassName MethodName argumentList
				String className = parseFQClassName();
				methodName = parseIdentifier();
				Object[] args = parseArgumentList();

				Class<?> cls = findClass( className );
				if( cls == null )
					return null;

				return getExpressionValue( cls, methodName, args );

			} else if( methodName.equals( "field" ) ) {
				// Syntax: FIELD FieldName (COLON value)?
				String fieldName = parseIdentifier();

				if( lexer.peekToken() == ':' ) {
					lexer.nextToken(); // skip ':'
					Object value = parseNonVoidValue( null );

					setFieldValue( outer, fieldName, value );
					return VOID;
				} else
					return getFieldValue( outer, fieldName );

			} else if( methodName.equals( "sfield" ) ) {
				// Syntax: STATIC_FIELD ClassName FieldName (COLON value)?
				String className = parseFQClassName();
				String fieldName = parseIdentifier();

				if( lexer.peekToken() == ':' ) {
					lexer.nextToken(); // skip ':'
					Object value = parseNonVoidValue( null );

					setStaticFieldValue( className, fieldName, value );
					return VOID;
				} else
					return getStaticFieldValue( className, fieldName );

			} else if( methodName.equals( "enum" ) ) {
				// Syntax: ENUM ClassName FieldName
				String className = parseFQClassName();
				String enumName = parseIdentifier();

				Class<?> cls = findClass( className );
				if( cls == null )
					return null;

				Object[] args = new Object[] { cls, enumName };
				return getExpressionValue( Enum.class, "valueOf", args );

			} else if( methodName.equals( "class" ) ) {
				// Syntax: CLASS ClassName
				String className = parseFQClassNameOrArray();

				return findClass( className );

			} else if( methodName.equals( "this" ) ) {
				return outer;

			} else
				throw new SyntaxException( "'(' or ':' expected", lexer.line, lexer.offset );

		} else if( token == Lexer.STRING ) {
			// Syntax: String COLON value

			// special property syntax:
			//     "propertyName": value
			// --> invoke outer.setProperty( "propertyName", value )
			String propName = (String) lexer.value;
			parseChar( ':' );
			Object value = parseNonVoidValue( null );
			Object[] args = new Object[] { propName, value };

			getExpressionValue( outer, "setProperty", args );
			return VOID;
		} else if( token == '#' ) {
			String id = parseIdentifier();
			if( idToValueMap == null || !idToValueMap.containsKey( id ) )
				throw new SyntaxException( "Unbound variable \"" + id + "\"" );
			return idToValueMap.get( id );

		} else if( token == '}' ) {
			lexer.pushBack();
		} else
			throw new SyntaxException( "Expression expected", lexer.line, lexer.offset );

		return null;
	}

	/**
	 * array
	 *     : LEFT_BRACKET+ valueList? RIGHT_BRACKET+
	 *     ;
	 */
	private Object parseArray( Class<?> componentType ) throws SyntaxException, IOException {
		// opening brackets
		int dimensions = 1;
		parseChar( '[' );
		while( lexer.peekToken() == '[' ) {
			dimensions++;
			lexer.nextToken(); // skip '['
		}

		// parse value list
		Object[] objArray;
		if( lexer.peekToken() == ']' )
			objArray = new Object[0];
		else
			objArray = parseValueList();

		// closing brackets
		for( int i = 0; i < dimensions; i++ )
			parseChar( ']' );

		if( componentType == null )
			return null;

		// create array
		Object array;
		if( dimensions == 1 )
			array = Array.newInstance( componentType, objArray.length );
		else {
			int[] dims = new int[dimensions];
			dims[0] = objArray.length;
			array = Array.newInstance( componentType, dims );
		}

		// copy data
		for( int i = 0; i < objArray.length; i++ )
			Array.set( array, i, objArray[i] );
		return array;
	}

	/**
	 * argumentList
	 *     : LEFT_PARENTHESES valueList? RIGHT_PARENTHESES
	 *     ;
	 */
	private Object[] parseArgumentList() throws SyntaxException, IOException {
		return parseValueListWithBrackets( '(', ')' );
	}

	private Object[] parseValueListWithBrackets( char left, char right ) throws SyntaxException, IOException {
		parseChar( left );
		if( lexer.nextToken() == right )
			return new Object[0];

		lexer.pushBack();
		Object[] values = parseValueList();
		parseChar( right );
		return values;
	}

	/**
	 * valueList
	 *     : value (COMMA value)*
	 *     ;
	 */
	private Object[] parseValueList() throws SyntaxException, IOException {
		ArrayList<Object> values = new ArrayList<>();

		do {
			values.add( parseNonVoidValue( null ) );
		} while( lexer.nextToken() == ',' );

		lexer.pushBack();
		return values.toArray();
	}

	private Object parseNonVoidValue( Object outer ) throws SyntaxException, IOException {
		Object value;
		do {
			value = parseValue( outer );
		} while( value == VOID );
		return value;
	}

	/**
	 * value
	 *     : String
	 *     | Char
	 *     | Number
	 *     | Boolean
	 *     | NULL
	 *     | object
	 *     ;
	 */
	private Object parseValue( Object outer ) throws SyntaxException, IOException {
		int token = lexer.nextToken();
		switch( token ) {
			case Lexer.IDENTIFIER:
				if( lexer.value.equals( "false" ) )
					return false;
				if( lexer.value.equals( "true" ) )
					return true;
				if( lexer.value.equals( "null" ) )
					return null;
				// fall thru

			case '&':
			case '#':
				lexer.pushBack();
				return parseObject( outer );

			case Lexer.STRING:
			case Lexer.CHAR:
			case Lexer.NUMBER:
				return lexer.value;

			case Lexer.EOF:
				throw new SyntaxException( "Unexpected end of file", lexer.line, lexer.offset );

			default:
				throw new SyntaxException( "Unexpected token '" + (char) token + "'", lexer.line, lexer.offset );
		}
	}

	/**
	 * @since 7.0.1
	 */
	private String parseFQClassNameOrArray() throws SyntaxException, IOException {
		String className = parseFQClassName();
		if( lexer.peekToken() != '[' )
			return className;

		StringBuilder arrayClassName = new StringBuilder();
		do {
			parseChar( '[' );
			parseChar( ']' );
			arrayClassName.append( '[' );
		} while( lexer.peekToken() == '[' );

		char encoding = 0;
		switch( className ) {
			case "boolean":		encoding = 'Z'; break;
			case "byte":		encoding = 'B'; break;
			case "char":		encoding = 'C'; break;
			case "double":		encoding = 'D'; break;
			case "float":		encoding = 'F'; break;
			case "int":			encoding = 'I'; break;
			case "long":		encoding = 'J'; break;
			case "short":		encoding = 'S'; break;
		}

		if( encoding != 0 )
			arrayClassName.append( encoding );
		else
			arrayClassName.append( 'L' ).append( className ).append( ';' );

		return arrayClassName.toString();
	}

	/**
	 * ClassName
	 *     : Identifier ('.' Identifier)*;
	 *     ;
	 */
	private String parseFQClassName() throws SyntaxException, IOException {
		StringBuilder className = new StringBuilder( parseIdentifier() );
		while( lexer.nextToken() == '.' )
			className.append( '.' ).append( parseIdentifier() );
		lexer.pushBack();
		return className.toString();
	}

	private String parseIdentifier() throws SyntaxException, IOException {
		if( lexer.nextToken() != Lexer.IDENTIFIER )
			throw new SyntaxException( "identifier expected", lexer.line, lexer.offset );
		return (String) lexer.value;
	}

	private void parseChar( char ch ) throws SyntaxException, IOException {
		if( lexer.nextToken() != ch )
			throw new SyntaxException( "'" + ch + "\' expected", lexer.line, lexer.offset );
	}

	private Class<?> findClass( String className ) {
		try {
			return findClassImpl( className );
		} catch( ClassNotFoundException ex ) {
			exceptionThrown( ex );
			return null;
		}
	}

	private Class<?> findClassImpl( String className )
		throws ClassNotFoundException
	{
		Class<?> primitiveType = primitiveTypeFor( className );
		if( primitiveType != null )
			return primitiveType;

		if( classNameMapper != null )
			className = classNameMapper.decode( className );

		ClassLoader loader = (classLoader != null)
			? classLoader
			: Thread.currentThread().getContextClassLoader();

		return Class.forName( className, false, loader );
	}

	private static Class<?> primitiveTypeFor( String className ) {
		if( primitiveTypeMap.isEmpty() ) {
			primitiveTypeMap.put( boolean.class.getName(), boolean.class );
			primitiveTypeMap.put( byte.class.getName(), byte.class );
			primitiveTypeMap.put( char.class.getName(), char.class );
			primitiveTypeMap.put( double.class.getName(), double.class );
			primitiveTypeMap.put( float.class.getName(), float.class );
			primitiveTypeMap.put( int.class.getName(), int.class );
			primitiveTypeMap.put( long.class.getName(), long.class );
			primitiveTypeMap.put( short.class.getName(), short.class );
			primitiveTypeMap.put( void.class.getName(), void.class );
		}

		return primitiveTypeMap.get( className );
	}

	private Object getExpressionValue( Object target, String methodName, Object[] args ) {
		try {
			return new Expression( target, methodName, args ).getValue();
		} catch( Exception ex ) {
			exceptionThrown( ex );
			return null;
		}
	}

	private Object getStaticFieldValue( String className, String name ) {
		try {
			Class<?> fieldClass = findClassImpl( className );
			Field field = getField( fieldClass, name, true );
			return field.get( null );
		} catch( Exception ex ) {
			exceptionThrown( ex );
			return null;
		}
	}

	private Object getFieldValue( Object target, String name ) {
		try {
			Field field = getField( target.getClass(), name, false );
			return field.get( target );
		} catch( Exception ex ) {
			exceptionThrown( ex );
			return null;
		}
	}

	private void setStaticFieldValue( String className, String name, Object value ) {
		try {
			Class<?> fieldClass = findClassImpl( className );
			Field field = getField( fieldClass, name, true );
			field.set( null, value );
		} catch( Exception ex ) {
			exceptionThrown( ex );
		}
	}

	private void setFieldValue( Object target, String name, Object value ) {
		try {
			Field field = getField( target.getClass(), name, false );
			field.set( target, value );
		} catch( Exception ex ) {
			exceptionThrown( ex );
		}
	}

	private Field getField( Class<?> fieldClass, String name, boolean staticField )
		throws NoSuchFieldException
	{
		Field field = fieldClass.getField( name );
		if( Modifier.isStatic( field.getModifiers() ) != staticField )
			throw new NoSuchFieldException( "Field \"" + name + "\" is "
				+ (staticField ? "" : "not ") + "static" );
		return field;
	}

	private static String capitalize( String prefix, String str ) {
		int prefixLength = prefix.length();
		int strLength = str.length();
		char[] chars = new char[prefixLength + strLength];
		prefix.getChars( 0, prefixLength, chars, 0 );
		str.getChars( 0, strLength, chars, prefixLength );
		chars[prefixLength] = Character.toUpperCase( chars[prefixLength] );
		return new String( chars );
	}

	//---- class Lexer --------------------------------------------------------

	static class Lexer
	{
		static final int EOF = -1;
		static final int IDENTIFIER = -2;
		static final int STRING = -3;
		static final int CHAR = -4;
		static final int NUMBER = -5;

		private static final int NEED_CHAR = Integer.MAX_VALUE;

		private final Reader reader;

		private char buffer[] = new char[100];
		private final char unicodeBuffer[] = new char[4];
		private int peekc = NEED_CHAR;

		private boolean pushedBack;

		int token;
		Object value;
		int line = 1;
		int offset = 0;

		Lexer( Reader reader ) {
			this.reader = reader;
		}

		void close() throws IOException {
			reader.close();
		}

		int nextToken() throws SyntaxException, IOException {
			if( pushedBack ) {
				pushedBack = false;
				return token;
			}

			value = null;

			int c = peekc;
			if( c < 0 )
				c = NEED_CHAR;
			if( c == NEED_CHAR ) {
				c = read();
				if( c < 0 )
					return token = EOF;
			}

			token = c;
			peekc = NEED_CHAR;

			// skip whitespace
			while( Character.isWhitespace( c ) ) {
				c = read();
				if( c < 0 )
					return token = EOF;
			}

			// identifier
			if( Character.isJavaIdentifierStart( c ) ) {
				int bufferIndex = 0;
				do {
					if( bufferIndex >= buffer.length )
						increaseBufferSize();
					buffer[bufferIndex++] = (char) c;
					c = read();
				} while( Character.isJavaIdentifierPart( c ) );

				peekc = c;
				value = new String( buffer, 0, bufferIndex );

				return token = IDENTIFIER;
			}

			// number
			if( (c >= '0' && c <= '9') || c == '-' ) {
				value = scanNumber( c );
				if( value == null )
					return token = c;
				return token = NUMBER;
			}

			// string
			if( c == '"' ) {
				value = scanString( c );
				return token = STRING;
			}

			// char
			if( c == '\'' ) {
				value = scanCharacter();
				return token = CHAR;
			}

			// comment
			if( c == '/' ) {
				c = read();
				if( c == '/' ) {
					// single line comment
					do {
						c = read();
					} while( c != '\n' && c != '\r' && c >= 0 );
					peekc = c;
					return nextToken();
				} else if( c == '*' ) {
					// multi-line comment
					int prevc;
					do {
						prevc = c;
						c = read();
					} while( c >= 0 && (c != '/' || prevc != '*') );
					return nextToken();
				} else {
					peekc = c;
					return token = '/';
				}
			}

			return token = c;
		}

		private String scanString( int quote ) throws SyntaxException, IOException {
			int bufferIndex = 0;
			for(;;) {
				int c = scanChar( '"' );
				if( c == -2 )
					break; // end of string

				if( c < 0 )
					throw new SyntaxException( "Unclosed string literal", line, offset );

				if( bufferIndex >= buffer.length )
					increaseBufferSize();
				buffer[bufferIndex++] = (char) c;
			}

			return new String( buffer, 0, bufferIndex );
		}

		private Character scanCharacter() throws SyntaxException, IOException {
			int c = scanChar( '\'' );
			if( c < 0 )
				throw new SyntaxException( "Invalid character constant", line, offset );

			Character value = Character.valueOf( (char) c );

			c = read();
			if( c != '\'' )
				throw new SyntaxException( "Invalid character constant", line, offset );

			return value;
		}

		private int scanChar( int quote ) throws SyntaxException, IOException {
			int c = read();
			if( c == quote )
				return -2;
			if( c != '\\' )
				return c;

			c = read();
			switch( c ) {
				case 'b': return '\b';
				case 't': return '\t';
				case 'n': return '\n';
				case 'f': return '\f';
				case 'r': return '\r';

				case '\\':
				case '\'':
				case '"':
					return c;

				case 'u':
					for( int i = 0; i < 4; i++ )
						unicodeBuffer[i] = (char) read();
					String str = new String( unicodeBuffer );
					try {
						return Integer.parseInt( str, 16 );
					} catch( NumberFormatException ex ) {
						throw new SyntaxException( "Invalid unicode escape sequence \"\\u" + str
							+ "\": " + ex.getMessage(), line, offset );
					}

				default:
					throw new SyntaxException( "Invalid escape sequence", line, offset );
			}
		}

		private Number scanNumber( int c ) throws SyntaxException, IOException {
			int bufferIndex = 0;

			if( c == '-' ) {
				c = read();
				if( c < '0' || c > '9' ) {
					peekc = c;
					return null;
				}
				buffer[bufferIndex++] = '-';
			}

			do {
				if( bufferIndex >= buffer.length )
					increaseBufferSize();
				buffer[bufferIndex++] = (char) c;
				c = read();
			} while( (c >= '0' && c <= '9') || c == '.' || c == '-' || c == 'e' || c == 'E' );

			String number = new String( buffer, 0, bufferIndex );
			try {
				switch( c ) {
					case 'b':	return Byte.valueOf( number );
					case 's':	return Short.valueOf( number );
					case 'l':	return Long.valueOf( number );
					case 'f':	return Float.valueOf( number );
					default:
						if( Character.isLetter( c ) ) {
							throw new SyntaxException( "unexpected letter '"
								+ (char) c + "' immediately following number \""
								+ number + "\"", line, offset );
						}

						peekc = c;

						if( number.indexOf( '.' ) >= 0 )
							return Double.valueOf( number );
						else
							return Integer.valueOf( number );
				}
			} catch( NumberFormatException ex ) {
				throw new SyntaxException( "failed to parse number \"" + number
					+ "\": " + ex.getMessage(), line, offset );
			}
		}

		int peekToken() throws SyntaxException, IOException {
			int token = nextToken();
			pushBack();
			return token;
		}

		void pushBack() throws SyntaxException {
			if( pushedBack )
				throw new SyntaxException( "already pushed back", line, offset );

			pushedBack = true;
		}

	    private int read() throws IOException {
			offset++;
			int c = reader.read();
			if( c == '\n' ) {
				line++;
				offset = 0;
			}
			return c;
		}

	    private void increaseBufferSize() {
			char newBuffer[] = new char[buffer.length * 2];
			System.arraycopy( buffer, 0, newBuffer, 0, buffer.length );
			buffer = newBuffer;
	    }
	}

	//---- class SyntaxException ----------------------------------------------

	static class SyntaxException
		extends Exception
	{
		SyntaxException( String message ) {
			super( message );
		}

		SyntaxException( String message, int line, int offset ) {
			super( message + " (line " + line + ':' + offset + ')' );
		}
	}
}
